from tkinter import *

r=Tk()
im=PhotoImage(file="hello.png")
im1=PhotoImage(file="hi.png")
c=Canvas(r,width="800",height="800",bg="yellow") # canvas "c" should be capital

c.create_image(100,100,image=im,activeimage=im1)#create _image is predefined function

# pack() #sides left right top bottom
# place() #place data positionally ussing x and y coordinates
# grid() #place data in rows and coloumns format

c.pack()
r.mainloop()
