from tkinter import *
r=Tk()

c=Canvas(r,width="800",height="800",bg="yellow") # canvas "c" should be capital

c.create_line(50,50,100,100,width=4,fill="red")#create _image is predefined function
c.create_rectangle(20,70,300,300,fill="green")
c.create_oval(50,150,200,350,fill="purple")

# pack() #sides left right top bottom
# place() #place data positionally ussing x and y coordinates
# grid() #place data in rows and coloumns format

c.pack()
r.mainloop()
